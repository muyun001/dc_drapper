# -*- coding: utf-8 -*-
import os
import sys
import random
import base64
import traceback

from download_center.new_spider.downloader.downloader import SpiderRequest
from download_center.new_spider.spider.basespider import BaseSpider
from download_center.util.util_log import UtilLogger

# 线上测试
PROJECT_PATH = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# print("PROJECT_PATH", PROJECT_PATH)
sys.path.append(PROJECT_PATH)
# sys.path.append(os.path.join(PROJECT_PATH, 'demo'))

from demo.extractor.baidu_extractor import BaiduExtractor
import time


class DemoSpider(BaseSpider):
    def __init__(self, remote=True):
        super(DemoSpider, self).__init__(remote=remote)
        self.log = UtilLogger('DemoSpider', os.path.join(os.path.dirname(os.path.abspath(__file__)), 'log_demo_spider'))
        self.ext = BaiduExtractor()

    def get_user_password(self):
        return 'test', 'test'

    def start_requests(self):
        try:
            urls = [{'url': "https://www.baidu.com/s?wd=%E6%8B%9B%E8%81%98", 'type': 1, "test": "test"}]
            headers = {
                "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.80 Safari/537.36",
            }
            request = SpiderRequest(headers=headers, urls=urls)
            self.sending_queue.put(request)
        except Exception:
            self.log.error('获取初始请求出错: {}'.format(traceback.format_exc()))

    def get_stores(self):
        # 存储器
        stores = list()
        return stores

    def deal_response_results_status(self, task_status, url, result, request):
        if task_status == '2':
            rdata = self.ext.extractor(result["result"])
            if isinstance(rdata, int):
                print("request ua: {}".format(request.headers["User-Agent"]))
            else:
                result_d, include, keyword_list = rdata
                print(result_d)
                print(include)
                print(keyword_list)

            with open("html_py3_3.txt", 'w', encoding="utf-8") as f:
                f.write(result["result"])
        else:
            self.log.info('抓取失败: {}'.format(url))

    def to_store_results(self,  results, stores):
        """
        结果存储按需使用
        :return:
        """
        pass


def main():
    spider = DemoSpider(remote=False)
    spider.run(1, 1, 1, 1, record_log=True)   # 测试
    # spider.run(spider_count=1000, record_log=True)
    # spider.run(record_log=True)               # error


if __name__ == '__main__':
    main()
