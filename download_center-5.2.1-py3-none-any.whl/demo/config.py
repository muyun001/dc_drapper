# -*- coding: utf8 -*-

HEALTH_DB = {
    'host': 'test',
    'user': 'test',
    'password': 'test',
    'db': 'test'
}
